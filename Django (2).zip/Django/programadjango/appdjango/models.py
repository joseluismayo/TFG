from django.db import models
from django.contrib.auth.models import AbstractBaseUser, BaseUserManager, PermissionsMixin
from django.db import models

from django.contrib.auth.models import AbstractBaseUser, BaseUserManager, PermissionsMixin
from django.db import models

class UsuarioManager(BaseUserManager):
    def create_user(self, correo, contrasena=None, **extra_fields):
        if not correo:
            raise ValueError('El correo debe ser proporcionado')
        correo = self.normalize_email(correo)
        user = self.model(correo=correo, **extra_fields)
        user.set_password(contrasena)
        user.save(using=self._db)
        return user

    def create_superuser(self, correo, contrasena=None, **extra_fields):
        extra_fields.setdefault('is_staff', True)
        extra_fields.setdefault('is_superuser', True)
        return self.create_user(correo, contrasena, **extra_fields)

class Usuario(AbstractBaseUser):
    nombre = models.CharField(max_length=50)
    correo = models.EmailField(unique=True)
    contrasena = models.CharField(max_length=400)
    last_login = models.DateTimeField(auto_now=True, null=True)
    
    # Campos adicionales que quieras agregar
    is_active = models.BooleanField(default=True)
    is_staff = models.BooleanField(default=False)

    objects = UsuarioManager()

    USERNAME_FIELD = 'correo'
    REQUIRED_FIELDS = ['nombre']

    class Meta:
        db_table = 'Usuario'



class Lugar(models.Model):
    latitud = models.FloatField()
    longitud = models.FloatField()

    class Meta:
        db_table = 'Lugar'


class Animales(models.Model):
    usuario = models.ForeignKey(Usuario, on_delete=models.CASCADE, related_name='animales') #hacemos una relacion manyToOne en la que ponemos que un usuario puede tener muchos animales
    nombreAnimal = models.CharField(max_length=50)
    cantidad = models.IntegerField()
    lugarEncuentro = models.ForeignKey(Lugar, on_delete=models.CASCADE) #relacionamos el atributo con la tabla lugar, haciendo que si se borra un lugar se borren todos los animales encontrados en ese lugar

    class Meta:
        db_table = 'Animales'



