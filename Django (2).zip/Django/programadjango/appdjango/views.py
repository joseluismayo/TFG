from django.shortcuts import render, redirect

from django.contrib.auth.hashers import check_password
from django.contrib.auth import authenticate, login
from django.contrib.auth.hashers import make_password
from .forms import LoginFormulario, RegistroFormulario
from .models import Usuario
from django.contrib.auth.models import User
from django.contrib import messages


def vistaLogin(request):
    if request.method == "POST":
        formulario = LoginFormulario(request.POST)
        if formulario.is_valid():
            correo = formulario.cleaned_data['correo']
            contrasena = formulario.cleaned_data['contrasena']
            # Obtener el usuario por correo
            usuario = Usuario.objects.get(correo=correo)
            print(usuario.contrasena)
            print(make_password("2"))
            if usuario is not None:
                print("hola")
                if usuario.contrasena == contrasena:
                    print("esta bien")
                    # Si la contraseña es correcta, se realiza el login
                    login(request, usuario)
                    return redirect('inicio')  # Redirige a la página de inicio
                else:
                    print("esta mal")
                    # Si la contraseña es incorrecta, se muestra un mensaje de error
                    messages.error(request, "Credenciales incorrectas.")
            else: 
                print("Credenciales inválidas") 
        else:
            # Si el formulario no es válido
            messages.error(request, "Formulario no válido.")
    else:
        formulario = LoginFormulario()

    return render(request, "appdjango/login.html", {"form": formulario})


def vistaRegistro(request):
    if request.method == "POST":
        formulario = RegistroFormulario(request.POST)
        if formulario.is_valid():
            username = formulario.cleaned_data['nombre']
            email = formulario.cleaned_data['correo']
            contrasena1 = formulario.cleaned_data['contrasena']

            contrasena_encriptada = make_password(contrasena1)

            nuevo_usuario = Usuario(nombre=username, correo = email, contrasena = contrasena1)
            nuevo_usuario.save()

            return redirect('login')
    else: 
        formulario = RegistroFormulario()
    return render(request, "appdjango/registro.html", {"form": formulario})

def vistaInicio(request):
    return render(request, 'appdjango/inicio.html')