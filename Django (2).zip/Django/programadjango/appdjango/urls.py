from django.urls import path

from django.contrib import admin
from .views import vistaLogin, vistaRegistro, vistaInicio  # Asegúrate de importar la vista 'vistaRegistro'

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', vistaLogin, name="login"),
    path('registro/', vistaRegistro, name='registro'),  # Aquí se define 'registro' como nombre
    path('inicio/', vistaInicio, name='inicio'),  # URL para la vista de inicio
]
