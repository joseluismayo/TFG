from django.db import models

class Usuarios(models.Model):
    nombre = models.CharField(max_length=50)
    correo = models.CharField(max_length=50)
    contrasena = models.CharField(max_length=400)

class Lugar(models.Model):
    latitud = models.FloatField()
    longitud = models.FloatField()


class Animales(models.Model):
    usuario = models.ForeignKey(Usuarios, on_delete=models.CASCADE, related_name='animales') #hacemos una relacion manyToOne en la que ponemos que un usuario puede tener muchos animales
    nombreAnimal = models.CharField(max_length=50)
    cantidad = models.IntegerField()
    lugarEncuentro = models.ForeignKey(Lugar, on_delete=models.CASCADE) #relacionamos el atributo con la tabla lugar, haciendo que si se borra un lugar se borren todos los animales encontrados en ese lugar



