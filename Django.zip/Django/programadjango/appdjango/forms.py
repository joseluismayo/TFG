from django import forms
from django.contrib.auth.models import User

class LoginFormulario(forms.Form):
    correo = forms.EmailField(label="Correo electrónico")
    contrasena = forms.CharField(widget=forms.PasswordInput, label="Contraseña")

class RegistroFormulario(forms.Form):
    nombre = forms.CharField(label="Nombre")
    correo = forms.EmailField(label="Correo electrónico")
    contrasena = forms.CharField(widget=forms.PasswordInput, label="Contraseña")