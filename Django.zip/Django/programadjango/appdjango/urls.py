from django.urls import path
from . import views

urlpatterns = [
    path("login/", views.vistaLogin, name="login"),
    path("home/", views.home, name="home"),  # Asegúrate de tener esta ruta
]
