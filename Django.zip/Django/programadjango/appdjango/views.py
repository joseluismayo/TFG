from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login
from django.contrib.auth.hashers import make_password
from .forms import LoginFormulario, RegistroFormulario
from .models import Usuario
from django.contrib import messages


def vistaLogin(request):
    if request.method == "POST":
        form = LoginFormulario(request.POST)
    else:
        form = LoginFormulario()

    return render(request, "appdjango/login.html", {"form": form})

def vistaRegistro(request):
    if request.method == "POST":
        form = RegistroFormulario(request.POST)
        if form.is_valid():
            username = form.cleaned_data['nombre']
            email = form.cleaned_data['correo']
            contrasena1 = form.cleaned_data['contrasena']

            contrasena_encriptada = make_password(contrasena1)

            nuevo_usuario = Usuario(nombre=username, correo = email, contrasena = contrasena_encriptada)
            nuevo_usuario.save()

            messages.success(request, '¡Usuario registrado!')

            #mandar a la pagina de inicio
    else: 
        form = RegistroFormulario()
    return render(request, "appdjango/registro.html", {"form": form})